let mobiles = [
    {
      id: 1,
      companyName: "Iphone",
      Model: "Iphone X",
      Ram: "3 GB",
      Rom: "64 GB",
      Price: "$218",
    },
    {
      id: 2,
      companyName: "Iphone",
      Model: "Iphone 12",
      Ram: "4 GB",
      Rom: "128 GB",
      Price: "$799",
    },
    {
      id: 3,
      companyName: "Iphone",
      Model: "Iphone 13",
      Ram: "4 GB",
      Rom: "128 GB",
      Price: "$1699",
    },
    {
      id: 4,
      companyName: "Samsung",
      Model: "Galaxy Note 5",
      Ram: "4 GB",
      Rom: "32 GB",
      Price: "$101",
    },
    {
      id: 5,
      companyName: "Samsung",
      Model: "Galaxy Note 8",
      Ram: "6 GB",
      Rom: "64 GB",
      Price: "$419",
    },
    {
      id: 6,
      companyName: "Samsung",
      Model: "Galaxy S22",
      Ram: "8 GB",
      Rom: "128 GB",
      Price: "$799",
    },
    {
      id: 7,
      companyName: "Oppo",
      Model: "Reno 8",
      Ram: "8 GB",
      Rom: "128 GB",
      Price: "$399",
    },
    {
      id: 8,
      companyName: "Oppo",
      Model: "A36",
      Ram: "8 GB",
      Rom: "256 GB",
      Price: "$353",
    },
    {
      id: 9,
      companyName: "Oppo",
      Model: "K10",
      Ram: "6 GB",
      Rom: "128 GB",
      Price: "$220",
    },
    {
      id: 10,
      companyName: "Google",
      Model: "Pixel 6",
      Ram: "8 GB",
      Rom: "128 GB",
      Price: "$599",
    },
    {
      id: 11,
      companyName: "Google",
      Model: "Pixel 7",
      Ram: "8 GB",
      Rom: "128 GB",
      Price: "$400",
    },
    {
      id: 12,
      companyName: "Google",
      Model: "Pixel 8",
      Ram: "8 GB",
      Rom: "256 GB",
      Price: "$600",
    },
    {
      id: 14,
      companyName: "Infinix",
      Model: "Hot 11",
      Ram: "4 GB",
      Rom: "64 GB",
      Price: "$128",
    },
    {
      id: 15,
      companyName: "Infinix",
      Model: "Note 11",
      Ram: "6 GB",
      Rom: "128 GB",
      Price: "$229",
    },
    {
      id: 16,
      companyName: "Xiaomi",
      Model: "Redmi 10",
      Ram: "4 GB",
      Rom: "64 GB",
      Price: "$173",
    },
    {
      id: 17,
      companyName: "Xiaomi",
      Model: "Redmi Note 10",
      Ram: "4 GB",
      Rom: "128 GB",
      Price: "$182",
    },
    {
      id: 18,
      companyName: "Xiaomi",
      Model: "Redmi K50",
      Ram: "8 GB",
      Rom: "128 GB",
      Price: "$368",
    },
  ];

//   ////////
document.getElementById("test1").innerHTML=mobiles.map(e=>
    `<option>${e.id}</option>`)
document.getElementById("test2").innerHTML=mobiles.map(e=>
        `<option>${e.companyName}</option>`)
        var  cname=document.getElementById("test2").value
console.log(cname)
const mobile=mobiles.filter((function(e){return e.companyName===cname}))

// console.log(mobile)
var searchinput=document.getElementById("searchinput");
function Search(){
    const mobile=mobiles.filter((function(e){return e.companyName===cname}))
    document.getElementById("result").innerHTML=mobile.map(e=>
        `<ul><li>${e.companyName}</li></ul>`)
}


   